
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Ayurvedic Healing</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
        }

        .navbar {
    width: 100%;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #16a085;
}

.logo {
    width: 150px;
}

.navbar ul {
    display: flex;
}

.navbar ul li {
    list-style: none;
    margin: 0 15px;
}

.navbar ul li a {
    color: #fff;
    text-transform: uppercase;
    text-decoration: none;
    padding: 5px 10px;
    transition: background 0.3s;
}

.navbar ul li a:hover {
    background: #4caea4;
    border-radius: 5px;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown .dropbtn {
    background-color: transparent;
    color: white;
    border: none;
    cursor: pointer;
    text-transform: uppercase;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #939595;
    min-width: 160px;
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    transition: background-color 0.3s ease;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #4fbaaf;
    border-radius: 5px;
}


        header {
            background: #16a085;
            padding: 50px;
            text-align: center;
            color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
        }

        header p {
            font-size: 1.2rem;
        }

        .contact-content {
            padding: 50px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        .contact-details, .contact-form {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .contact-details h2, .contact-form h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #16a085;
        }

        .contact-details p, .contact-form label {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 10px;
        }

        .contact-details ul {
            list-style: none;
            padding: 0;
        }

        .contact-details ul li {
            margin-bottom: 15px;
        }

        .contact-details ul li i {
            color: #16a085;
            margin-right: 10px;
            font-size: 1.5rem;
        }

        .contact-form form {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }

        .contact-form input, .contact-form textarea {
            padding: 15px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }

        .contact-form button {
            background-color: #16a085;
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.2rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .contact-form button:hover {
            background-color: #128971;
        }

        .map-section {
            margin-top: 40px;
        }

        .map-section iframe {
            width: 100%;
            height: 400px;
            border: none;
        }

        footer {
            background-color: #2c3e50;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        footer p {
            margin: 0;
            font-size: 1rem;
        }

        footer a {
            color: #1abc9c;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .contact-grid {
                grid-template-columns: 1fr;
            }

            header h1 {
                font-size: 2.5rem;
            }

            .contact-details h2, .contact-form h2 {
                font-size: 1.5rem;
            }

            .contact-details p, .contact-form label {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>


    <div id="google_translate_element"></div>

    <div class="navbar">
        <img src=".jpg" class="logo" alt="">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Location -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                    
                    
                </div>
            </li>
            
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>

    <!-- Header -->
    <header>
        <h1>Contact Ayurvedic Healing</h1>
        <p>We'd love to hear from you!</p>
    </header>

    <!-- Main Contact Content -->
    <div class="contact-content">
        <div class="contact-grid">
            <!-- Contact Details Section -->
            <div class="contact-details">
                <h2>Get in Touch</h2>
                <p>For any queries, suggestions, or feedback, feel free to reach out to us:</p>
                <ul>
                    <li><i class="fas fa-map-marker-alt"></i> 1234 Nature Road, Wellness City, India</li>
                    <li><i class="fas fa-phone"></i> +1 234 567 890</li>
                    <li><i class="fas fa-envelope"></i> info@ayurvedichealing.com</li>
                    <li><i class="fas fa-clock"></i> Mon - Fri: 9:00 AM - 6:00 PM</li>
                </ul>
            </div>

            <!-- Contact Form Section -->
            <div class="contact-form">
                <h2>Send Us a Message</h2>
                <form action="#">
                    <label for="name">Your Name</label>
                    <input type="text" id="name" name="name" placeholder="Enter your name" required>

                    <label for="email">Your Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>

                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="6" placeholder="Write your message here" required></textarea>

                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>

    <!-- Footer -->
    <footer>
        <p>Contact us: <a href="mailto:info@ayurvedichealing.com">info@ayurvedichealing.com</a> | +1 234 567 890</p>
        <p>&copy; 2024 Ayurvedic Healing. All rights reserved.</p>
    </footer>

</body>
</html>
