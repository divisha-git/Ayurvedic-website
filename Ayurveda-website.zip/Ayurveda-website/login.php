<?php
  $registered=0;
  $userexists=0;
  if($_SERVER['REQUEST_METHOD']=='POST'){
      include 'server.php';
      $name=$_POST['username'];
      $password=$_POST['password'];
     
      $sql="SELECT * FROM register WHERE Email='$name'";
      $result=mysqli_query($con,$sql);
      if($result){
        $num=mysqli_num_rows($result);
        if($num>0){
            $userexists=1;
        }
        else{
            $sql="INSERT INTO register(First name,Password) VALUES('$name','$password')";
          $result=mysqli_query($con,$sql);
          if($result){
            $registered=1;
          }
          else{
            die(mysqli_error($con));
          }
        }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayurvedic Healing - Login</title>
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>



</head>
<body>


    <div id="google_translate_element"></div>

    
    <div class="navbar">
        <img src=".jpg" class="logo" alt="">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Location -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                
                </div>
            </li>
            
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <img src="ayulogo.png" alt="Ayurvedic Logo" class="logo">
                <h2>Welcome to Ayurvedic Healing</h2>
                <p>Log in to your account</p>
            </div>

            <form id="loginForm" action="./login.php" method="post">
                <div class="input-box">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" placeholder="Email" name="username" required>
                </div>
                <div class="input-box">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" placeholder="Password" name="password" required>
                </div>
                <div class="forgot-password">
                    <a href="#" onclick="showForgotPassword()"><center>Forgot Password?</center></a>
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>

            <div id="forgot-password-box" class="hidden">
                <h3>Reset Your Password</h3>
                <p>Enter your email to receive a reset link.</p>
                <input type="email" id="reset-email" placeholder="Email" required>
                <button class="reset-btn" onclick="sendResetLink()">Send Reset Link</button>
            </div>

            <div class="signup-link">
                <p>Don't have an account? <a href="form.php">Sign Up</a></p>
            </div>
        </div>
    </div>

    <script src="script3.js"></script>
</body>
</html>
