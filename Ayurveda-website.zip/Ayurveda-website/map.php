<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayurvedic Shop and Hospital Locator</title>
    
    <!-- Google Fonts for enhanced typography -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript">
    function googleTranslateElementInit(){
        new google.translate.TranslateElement({
            pageLanguage: 'en', // Set the default language to English
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    
    <!-- Internal Styling for a sleek, modern look -->
    <style>
        /* Global Reset and Body Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #A2D9CE, #E8DAEF);
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: left;
            min-height: 100vh;
            padding-top: 100px;
        }

        /* Navbar Styling */
        .navbar {
            width: 100%;
            background: #28a79c;
            padding: 55px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: left;
            position: fixed;
            top: 0;
            z-index: 1000;
        }

        .navbar ul {
            display: flex;
            list-style: none;
        }

        .navbar ul li {
            margin: 0 20px;
        }

        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s ease;
            text-transform: uppercase;
        }

        .navbar ul li a:hover {
            background: #aab0af;
        }

        /* Dropdown Styling */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown .dropbtn {
            background-color: transparent;
            color: rgb(251, 248, 248);
            font-weight: bold;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
            text-transform: uppercase;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #55e6e4;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
        }

        .dropdown-content a {
            color: rgb(13, 11, 11);
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s ease;
        }

        .dropdown-content a:hover {
            background-color: #aaa7a7;
        }

        /* Show dropdown on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: #909494;
        }

        /* Google Translate Styling */
        #google_translate_element {
            position: absolute; /* Positioning it absolutely */
            top: 20px; /* Adjust the top position */
            left: 20px; /* Align it to the left */
            z-index: 1000; /* Ensure it stays on top of other elements */
        }

        /* Apply scroll behavior for the Google Translate dropdown */
        .goog-te-menu-value {
            overflow-y: auto; /* Enable vertical scrolling */
            max-height: 30px; /* Limit the height of the language selector */
        }

        /* Apply a fixed height and scrolling for the language menu */
        .goog-te-menu {
            max-height: 300px; /* Limit the height of the menu */
            overflow-y: auto; /* Enable scrolling if the menu overflows */
        }

        /* Header */
        h1 {
            margin-top: 120px;
            font-size: 2.5em;
            color: #029c8fde;
            font-family: 'Times New Roman', Times, serif;
        }

        /* Input and Button Styling */
        input[type="text"] {
            padding: 12px;
            width: 300px;
            font-size: 16px;
            border: 2px solid #28a79c;
            border-radius: 5px;
            margin-top: 50px;
        }

        button {
            padding: 12px 20px;
            font-size: 16px;
            font-family: 'Times New Roman', Times, serif;
            background-color: #2acabd;
            color: white;
            margin-top: 50px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #00fad9;
        }

        /* Footer */
        footer {
            margin-top: auto;
            padding: 15px;
            background-color: #28a79c;
            color: white;
            text-align: center;
            width: 100%;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
            position: fixed;
            bottom: 0;
        }
    </style>
</head>
<body>


    <!-- Google Translate Element -->
    <div id="google_translate_element"></div>

    
    <!-- Navbar -->
    <div class="navbar">
        <ul>
            <li><a href="index.php">HOME</a></li>
            <li><a href="product.php">PRODUCT</a></li>
            <li><a href="formulation.php">FORMULATION</a></li>
            
            <!-- Dropdown Menu for Explore -->
            <li class="dropdown">
                <a href="javascript:void(0)" class="dropbtn">EXPLORE</a>
                <div class="dropdown-content">
                    <a href="contact.php">CONTACT US</a>
                    <a href="about.php">ABOUT US</a>
                    <a href="map.php">LOCATION</a>
                </div>
            </li> 
            <li><a href="login.php">LOGIN</a></li>
            <li><a href="form.php">REGISTER</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <h1>Find Ayurvedic Shops and Hospitals</h1>

    <input type="text" id="location" placeholder="Enter a city (e.g., Salem)" />
    <button onclick="redirectToGoogleMaps()">Find Ayurvedic Shops</button>

    <!-- JavaScript -->
    <script>
        function redirectToGoogleMaps() {
            const location = document.getElementById("location").value || "Namakkal";  // Default to Namakkal if no input
            const searchQuery = "Ayurvedic shops and hospitals in " + location;
            window.open(`https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`, '_blank');
        }
    </script>

    <!-- Footer -->
    <footer>
        © 2024 Ayurvedic Shop Locator | All Rights Reserved
    </footer>

</body>
</html>
