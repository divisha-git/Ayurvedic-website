// Replace with your Google API Key
const apiKey = 'YOUR_GOOGLE_API_KEY'; // Add your Google API key here
const translations = {};

// Change language function
async function changeLanguage() {
    const selectedLanguage = document.getElementById("language-select").value;

    // Translate each element with a data-key attribute
    const elementsToTranslate = document.querySelectorAll("[data-key]");
    for (let element of elementsToTranslate) {
        const key = element.getAttribute("data-key");
        const originalText = element.getAttribute("data-original") || element.textContent;

        // Store the original text if not already stored
        if (!element.getAttribute("data-original")) {
            element.setAttribute("data-original", originalText);
        }

        // If translation is already cached, use it
        if (translations[selectedLanguage] && translations[selectedLanguage][key]) {
            element.textContent = translations[selectedLanguage][key];
        } else {
            // Fetch translation from Google Translate API
            const translatedText = await fetchTranslation(originalText, selectedLanguage);
            if (translatedText) {
                element.textContent = translatedText;

                // Cache the translation to reduce API calls
                if (!translations[selectedLanguage]) translations[selectedLanguage] = {};
                translations[selectedLanguage][key] = translatedText;
            }
        }
    }
}

// Fetch translation from Google Translate API
async function fetchTranslation(text, targetLang) {
    const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            q: text,
            target: targetLang,
        })
    });

    const data = await response.json();
    if (data && data.data && data.data.translations && data.data.translations.length > 0) {
        return data.data.translations[0].translatedText;
    }
    return null;
}

// Initialize with default language
window.addEventListener("load", () => {
    document.getElementById("language-select").value = "en"; // Default language
    changeLanguage(); // Set default translations on load
});
