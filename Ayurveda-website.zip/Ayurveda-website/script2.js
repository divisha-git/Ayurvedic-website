const ayurvedicMedicineMap = {
    "fever": {
        "medicine": "Tulsi Tea",
        "preparation": "1. Boil water. \n2. Add 5-6 tulsi leaves. \n3. Let it simmer for 10 minutes. \n4. Add honey and drink twice a day."
    },
    "cold": {
        "medicine": "Turmeric Milk",
        "preparation": "1. Heat a glass of milk. \n2. Add 1 tsp turmeric powder. \n3. Stir well and drink warm before bed."
    },
    "cough": {
        "medicine": "Ginger Honey Mixture",
        "preparation": "1. Grate fresh ginger (1 tsp). \n2. Mix with 1 tsp honey. \n3. Consume this twice a day."
    },
    "indigestion": {
        "medicine": "Ajwain (Carom Seeds) Water",
        "preparation": "1. Boil 1 tsp of ajwain in water for 5 minutes. \n2. Strain and drink after meals."
    },
    "headache": {
        "medicine": "Peppermint Tea",
        "preparation": "1. Boil water. \n2. Add 5-6 peppermint leaves. \n3. Let it steep for 10 minutes. \n4. Drink warm."
    },
    "constipation": {
        "medicine": "Triphala Powder",
        "preparation": "1. Mix 1 tsp of Triphala powder in warm water. \n2. Drink before bed daily for regular bowel movements."
    },
    "arthritis": {
        "medicine": "Ashwagandha Powder",
        "preparation": "1. Mix 1 tsp of Ashwagandha powder with warm water. \n2. Drink twice daily to reduce inflammation."
    },
    "acidity": {
        "medicine": "Amla Juice",
        "preparation": "1. Mix 2 tsp of Amla juice in warm water. \n2. Drink on an empty stomach in the morning."
    },
    "diarrhea": {
        "medicine": "Pomegranate Peel Tea",
        "preparation": "1. Dry pomegranate peels. \n2. Boil 1 tsp of dried peel in water for 10 minutes. \n3. Strain and drink twice a day."
    },
    "hypertension": {
        "medicine": "Sarpagandha Powder",
        "preparation": "1. Mix 1 tsp of Sarpagandha powder in warm water. \n2. Drink once daily to control blood pressure."
    },
   "skininfection": {
        "medicine": "Neem Paste",
        "preparation": "1. Grind fresh neem leaves to make a paste. \n2. Apply on the affected area. \n3. Leave it for 30 minutes and rinse."
    },
    "diabetes": {
        "medicine": "Jamun Seed Powder",
        "preparation": "1. Take 1 tsp of Jamun seed powder. \n2. Mix it in warm water. \n3. Drink once daily."
    },
    "asthma": {
        "medicine": "Vasa (Adhatoda Vasica)",
        "preparation": "1. Prepare Vasa leaf decoction by boiling leaves in water. \n2. Drink it twice daily."
    },
    "eczema": {
        "medicine": "Turmeric and Sandalwood Paste",
        "preparation": "1. Mix turmeric powder with sandalwood paste. \n2. Apply on the affected area and leave for 20 minutes."
    },
    "insomnia": {
        "medicine": "Ashwagandha Root Powder",
        "preparation": "1. Mix 1 tsp of Ashwagandha powder in warm milk. \n2. Drink before bedtime for better sleep."
    },
    "hairloss": {
        "medicine": "Amla Oil",
        "preparation": "1. Massage Amla oil into the scalp. \n2. Leave it for 1 hour before washing with a mild shampoo."
    },
    "ulcers": {
        "medicine": "Licorice Root Tea",
        "preparation": "1. Boil 1 tsp of licorice root in water for 10 minutes. \n2. Strain and drink twice daily."
    },
    "stress": {
        "medicine": "Brahmi Juice",
        "preparation": "1. Mix 2 tsp of Brahmi juice in a glass of water. \n2. Drink once daily to reduce stress."
    },
    "liverdisorders": {
        "medicine": "Kutki (Picrorhiza Kurroa)",
        "preparation": "1. Boil Kutki powder in water. \n2. Drink it twice daily to support liver health."
    },
    "kidneystones": {
        "medicine": "Pomegranate Juice",
        "preparation": "1. Drink fresh pomegranate juice daily to help dissolve kidney stones."
    },
    "highcholesterol": {
        "medicine": "Fenugreek Seeds",
        "preparation": "1. Soak 1 tsp of fenugreek seeds in water overnight. \n2. Consume it on an empty stomach in the morning."
    },
    "anemia": {
        "medicine": "Beetroot Juice",
        "preparation": "1. Drink a glass of fresh beetroot juice daily to boost iron levels."
    },
    "gastritis": {
        "medicine": "Coriander Seed Tea",
        "preparation": "1. Boil 1 tsp of coriander seeds in water for 10 minutes. \n2. Strain and drink twice daily."
    },
    "musclepain": {
        "medicine": "Turmeric and Mustard Oil Paste",
        "preparation": "1. Mix turmeric powder with mustard oil to form a paste. \n2. Apply on the affected muscles and leave for 30 minutes."
    },
    "bronchitis": {
        "medicine": "Thyme Tea",
        "preparation": "1. Boil 1 tsp of thyme leaves in water. \n2. Strain and drink twice daily to relieve bronchitis symptoms."
    },
    "allergy": {
        "medicine": "Honey with Ginger",
        "preparation": "1. Mix 1 tsp honey with a pinch of ginger powder. \n2. Take it twice a day to reduce allergy symptoms."
    },
    "toothache": {
        "medicine": "Clove Oil",
        "preparation": "1. Soak a cotton ball in clove oil. \n2. Apply to the affected tooth for pain relief."
    },
    "jaundice": {
        "medicine": "Neem and Turmeric Juice",
        "preparation": "1. Blend neem leaves and turmeric. \n2. Strain and drink the juice once daily."
    },
    "menstrualcramps": {
        "medicine": "Cinnamon Tea",
        "preparation": "1. Boil 1 tsp of cinnamon powder in water. \n2. Strain and drink warm."
    },
    "earache": {
        "medicine": "Garlic Oil",
        "preparation": "1. Heat garlic in sesame oil. \n2. Cool and apply a few drops in the ear."
    },
    "sorethroat": {
        "medicine": "Licorice Tea",
        "preparation": "1.Boil 1 tsp of licorice root in water for 10 minutes. \n2.Strain and drink warm. \n3.Consume twice daily for relief."
    },
    "stomachulcer": {
        "medicine": " Banana with Honey",
        "preparation": "1.Take a ripe banana. \n2.Mash it and mix with 1 tsp of honey. \n3.Eat twice a day to soothe the stomach lining."
        },
    "fatigue": {
        "medicine": "Ashwagandha Milk",
        "preparation": "1. Mix 1 tsp of ashwagandha powder in warm milk. \n2.Drink once daily for energy and strength."
        },
    "eyestrain": {
        "medicine": "Rose Water Eye Wash",
        "preparation": "Add a few drops of pure rose water into a bowl of cold water. \n2.Rinse your eyes with this solution for relief."
    },
    "jointpain": {
        "medicine": "Castor Oil Massage",
        "preparation": "1.Warm a small amount of castor oil. \n2.Massage onto the affected joints before bed. \n3.Leave overnight and wash in the morning for pain relief."
    },
    "constipation": {
        "medicine": "Triphala Powder",
        "preparation": "1. Mix 1 tsp of Triphala powder in warm water. \n2. Drink before bed daily."
    },
    "cough": {
        "medicine": "Honey and Lemon",
        "preparation": "1. Mix 1 tsp honey with 1 tsp lemon juice. \n2. Consume this mixture twice a day."
    },
    "headache": {
        "medicine": "Basil Tea",
        "preparation": "1. Boil water and add basil leaves. \n2. Steep for 10 minutes and drink warm."
    },
    "indigestion": {
        "medicine": "Fennel Seeds",
        "preparation": "1. Chew 1 tsp of fennel seeds after meals to aid digestion."
    },
    "allergies": {
        "medicine": "Echinacea Tea",
        "preparation": "1. Boil Echinacea leaves in water for 10 minutes. \n2. Strain and drink once daily."
    },
    "sinusitis": {
        "medicine": "Turmeric and Ginger tea",
        "preparation": "1.Boil 1 cup of water in a pot. \n2.Add 1 teaspoon of turmeric powder and fresh grated ginger. \n3.Let it simmer for 5-10 minutes. \n4.Strain the mixture into a cup. \n5.Add honey for taste, if desired. \n6.Drink this tea twice daily."
    },
    "insomnia": {
        "medicine": "Valerian Root Tea",
        "preparation": "1. Boil valerian root in water. \n2. Strain and drink before bedtime."
    },
    "musclepain": {
        "medicine": "Epsom Salt Bath",
        "preparation": "1. Dissolve 1-2 cups of Epsom salt in warm bath water. \n2. Soak for 15-20 minutes."
    },
    "coldsore": {
        "medicine": "Aloe Vera Gel",
        "preparation": "1. Apply fresh aloe vera gel directly to the cold sore."
    },
    "hypertension": {
        "medicine": "Hawthorn Berry Tea",
        "preparation": "1. Boil 1 tsp of hawthorn berries in water. \n2. Strain and drink once daily."
    },
    "heartproblem": {
        "medicine": "Arjuna Bark Powder",
        "preparation": "1. Boil 1 tsp of Arjuna bark powder in a cup of water. \n2.Let it simmer for 10 minutes. \n3.Strain and drink this once or twice daily for heart health."
    },
    "stomachpain":{
    "medicine": "Ginger (Zingiber officinale)",
    "preparation": "1.Grate a small piece of fresh ginger. \n2.Boil it in water for 10 minutes. \n3.Strain and drink this tea."
},
    "smallpox":{
    "medicine": "Nimba (Neem)",
    "preparation": "1.Collect fresh neem leaves. \n2.Wash them thoroughly and grind into a fine paste. \n3.Apply the paste directly on the affected area to soothe skin and prevent infection."
},   
    "tuberculosis":{
    "medicine": " Ashwagandha",
    "preparation": "1.Mix 1 tsp of ashwagandha powder in warm water or milk. \n2.Consume twice daily for enhanced immunity."
},
    "yellowfever":{
    "medicine": "Giloy Decoction",
    "preparation": "1.Boil Giloy stems in water. \n2.Reduce to half, strain, and drink once daily."
},
    "malaria":{
    "medicine": "Guduchi (Tinospora Cordifolia) Decoction",
    "preparation": "1.Take 1-2 tablespoons of Guduchi stem (Tinospora Cordifolia). \n2.Boil the stem in 2 cups of water. \n3.Let it simmer until the water reduces to half (around 1 cup). \n4.Strain the decoction."
},
    "hippain":{
    "medicine": "Mahanarayan Oil",
    "preparation": "1.Warm the oil slightly. \n2.Apply the oil gently to the affected hip area. \n3.Massage in circular motions for 10-15 minutes. \n4.Cover the area with a warm cloth for better absorption."
},
    "influenza":{
    "medicine": "Vasaka (Adhatoda vasica)",
    "preparation": "1.Grate a small piece of fresh ginger. \n2.Boil it in water for 10 minutes. \n3.Strain and drink this tea."
},




};
const alternativeNamesMap = {
    "earpain": "earache",
    "feverish": "fever",
    "headpain": "headache",
    "indigestionpain": "indigestion",
    "indigestionproblem":"indigestion",
    "stomachache":"stomachpain",
    "tension":"hypertension",
    "legpain":"jointpain",
    "legache":"jointpain",
    "allergy":"allergies",
    "skinallergy":"allergies",
    "digestionproblem":"indigestion",
     "eyepain":"eyestrain",
     "throatinfection":"sorethroat",
     "throatproblem":"sorethroat",
     "throatpain":"sorethroat",
     "gastricproblem":"gastritis",
     "hairfall":"hairloss",
     "menstrualpain":"menstrualcramps",
     "menstrualproblem":"menstrualcramps",
     "menstrualcramp":"menstrualcramps",
     "toothpain":"toothache",
     "kneepain":"jointpain",
     "heartdisease": "heartproblem",
     "cardiacissue": "heartproblem",
     "cardiacproblem": "heartproblem",
     "ulcer":"stomachulcer",

    
};

function getSuggestions() {
   
    let disease = document.getElementById('disease').value.toLowerCase().replace(/\s+/g, '').trim();
    const resultDiv = document.getElementById('result');
    if (disease === "") {
        alert("Please fill in the details");
        return;
    }

    if (alternativeNamesMap[disease]) {
        disease = alternativeNamesMap[disease];
    }

    if (ayurvedicMedicineMap[disease]) {
        const suggestion = ayurvedicMedicineMap[disease];
        resultDiv.innerHTML = `
            <strong>Medicine:</strong> ${suggestion.medicine} <br>
            <strong>Preparation Steps:</strong> <pre>${suggestion.preparation}</pre>
        `;
    } else {
        resultDiv.innerHTML = "<strong>No Ayurvedic suggestion available for the given disease.</strong>";
        resultDiv.style.animation = 'slideUp 0.5s ease-out';
    }
}


const voiceBtn = document.getElementById('voiceBtn');
const resultDiv = document.getElementById('result');

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

voiceBtn.addEventListener('click', () => {
    recognition.start();
});

recognition.onresult = (event) => {
    const speechResult = event.results[0][0].transcript.toLowerCase().trim();
    console.log('Recognized speech:', speechResult);
    document.getElementById('disease').value = speechResult; // Set the input field

    
    getSuggestions(); 
};

recognition.onerror = (event) => {
    console.error('Speech recognition error detected: ' + event.error);
    resultDiv.innerHTML = "<strong>Sorry, I didn't catch that. Please try again.</strong>";
};
