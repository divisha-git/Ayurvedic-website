<?php
$HOSTNAME='localhost';
$USERNAME='';
$PASSWORD='';
$DATABASE='root';
$con=mysqli_connect($HOSTNAME,$USERNAME,$PASSWORD,$DATABASE);
if($con)
{
    echo "connection successfully";
}
else{
    die(mysqli_error($con));
}
?>